import { assetPath } from '@/lib/site-path';
import Experience from './experience';
import { ArrowUpRight, ArrowDown, MapPin } from 'lucide-react';
const APPLY = 'https://airtable.com/appYGzY0JrDeFUXt1/pagS4DK5wd8cPRm4g/form';
export const dynamic = 'force-static';
export default function Home() {
  return <main id="top">
    <header className="header wrap">
      <a className="brand" href="#top" aria-label="Hack Midwest home"><img className="original-brand" src={assetPath("/original/img/logo.png")} alt="Hack Midwest" width="756" height="124"/></a>
      <nav aria-label="Main navigation"><a href="#about">The experience</a><a href="#prizes">The stakes</a><a href="#schedule">The weekend</a><a href="#faq">FAQ</a></nav>
      <a className="button small" href={APPLY} target="_blank" rel="noreferrer">Apply to build <ArrowUpRight size={18}/></a>
    </header>
    <section className="hero wrap" aria-labelledby="hero-title">
      <div className="hero-top mono"><span><i className="status-dot"/>KANSAS CITY’S LARGEST HACKATHON</span><span>OCTOBER 10—11 <span className="dim">/</span> 2026</span></div>
      <div className="hero-content">
        <div className="hero-copy"><p className="eyebrow">CALLING ALL BUILDERS, BREAKERS & BIG THINKERS.</p><h1 id="hero-title">BIG IDEAS.<br/>BOLD <span>BUILDS.</span></h1><p className="hero-description">Your next big thing starts with one wild idea.<br className="desktop-break"/> Build it in 24 hours. With 350+ of your people.</p><div className="hero-actions"><a className="button" href={APPLY} target="_blank" rel="noreferrer">Make your move <ArrowUpRight size={20}/></a><a className="text-link" href="#about">Explore the experience <ArrowDown size={17}/></a></div><div className="hero-location"><MapPin size={16}/> Kansas City, Missouri <span>•</span> In person. All in.</div></div>
        <div className="hero-art"><img src={assetPath("/images/chrome-star.png")} alt="A folded chrome star reflecting electric blue light" width="1254" height="1254" fetchPriority="high"/><span className="art-label mono">IDEAS INTO REALITY.<br/>24:00:00 TO MAKE IT HAPPEN.</span><span className="art-coordinate mono">39.0997° N<br/>94.5786° W</span></div>
      </div>
      <div className="hero-bottom"><span className="mono dim">PRESENTED BY</span><img src={assetPath("/images/flex-w.png")} alt="Flex" width="92" height="38"/><a href="#about" className="scroll-cue mono">SCROLL TO GET INSPIRED <ArrowDown size={17}/></a></div>
    </section>
    <section className="stat-band" aria-label="Hack Midwest in numbers"><div className="wrap stats"><div><strong>24<span>h</span></strong><span>TO BUILD SOMETHING GREAT</span></div><div><strong>350<span>+</span></strong><span>ENGINEERS. ENDLESS POSSIBILITIES.</span></div><div><strong>$10<span>k</span></strong><span>IN CASH. YOURS TO WIN.</span></div><div><strong>01</strong><span>WEEKEND THAT CHANGES THINGS.</span></div></div></section>
    <Experience/>
  </main>;
}
