'use client';
import { useEffect, useRef, useState, type ReactNode } from 'react';
import { ArrowLeft, ArrowRight, MoveHorizontal } from 'lucide-react';
import { ScrollArea, ScrollBar } from '@/components/ui/scroll-area';
import { Button } from '@/components/ui/button';
import { railMotion } from './rail-motion';

/** A contained horizontal reading lane. Wheel gestures release at either edge. */
export default function HorizontalRail({ children, label, className = '' }: { children: ReactNode; label: string; className?: string }) {
  const root = useRef<HTMLDivElement>(null);
  const [progress, setProgress] = useState(0);
  const [overflow, setOverflow] = useState(false);
  const viewport = () => root.current?.querySelector<HTMLElement>('[data-slot="scroll-area-viewport"]');
  useEffect(() => {
    const el = viewport();
    if (!el) return;
    const update = () => {
      const max = el.scrollWidth - el.clientWidth;
      setOverflow(max > 2);
      setProgress(max > 0 ? Math.min(1, Math.max(0, el.scrollLeft / max)) : 0);
    };
    const wheel = (event: WheelEvent) => {
      if (event.ctrlKey || event.defaultPrevented) return;
      const max = el.scrollWidth - el.clientWidth;
      const unit = event.deltaMode === 1 ? 16 : event.deltaMode === 2 ? el.clientWidth : 1;
      const delta = (Math.abs(event.deltaX) > Math.abs(event.deltaY) ? event.deltaX : event.deltaY) * unit;
      const motion = railMotion(el.scrollLeft, max, delta);
      if (max > 2 && Math.abs(motion.consumed) > .5) {
        event.preventDefault();
        el.scrollLeft = motion.next;
        if (Math.abs(event.deltaY) >= Math.abs(event.deltaX) && motion.remainder) window.scrollBy({ top: motion.remainder, behavior: 'instant' });
      }
    };
    let touch: { x: number; y: number; axis: 'x' | 'y' | null } | null = null;
    const touchStart = (event: TouchEvent) => {
      touch = event.touches.length === 1 ? { x: event.touches[0].clientX, y: event.touches[0].clientY, axis: null } : null;
    };
    const touchMove = (event: TouchEvent) => {
      if (!touch || event.touches.length !== 1) return;
      const point = event.touches[0];
      const dx = touch.x - point.clientX;
      const dy = touch.y - point.clientY;
      if (!touch.axis && Math.max(Math.abs(dx), Math.abs(dy)) < 4) return;
      touch.axis ??= Math.abs(dx) > Math.abs(dy) ? 'x' : 'y';
      const motion = railMotion(el.scrollLeft, el.scrollWidth - el.clientWidth, touch.axis === 'x' ? dx : dy);
      if (event.cancelable) event.preventDefault();
      el.scrollLeft = motion.next;
      if (touch.axis === 'y' && motion.remainder) window.scrollBy({ top: motion.remainder, behavior: 'instant' });
      touch.x = point.clientX;
      touch.y = point.clientY;
    };
    const touchEnd = () => { touch = null; };
    const keyboard = (event: KeyboardEvent) => {
      if (event.target !== el || !['ArrowLeft', 'ArrowRight', 'Home', 'End'].includes(event.key)) return;
      event.preventDefault();
      const max = el.scrollWidth - el.clientWidth;
      const target = event.key === 'Home' ? 0 : event.key === 'End' ? max : el.scrollLeft + (event.key === 'ArrowRight' ? 1 : -1) * el.clientWidth * .8;
      el.scrollTo({ left: target, behavior: matchMedia('(prefers-reduced-motion: reduce)').matches ? 'instant' : 'smooth' });
    };
    el.addEventListener('wheel', wheel, { passive: false });
    el.addEventListener('scroll', update, { passive: true });
    el.addEventListener('keydown', keyboard);
    el.addEventListener('touchstart', touchStart, { passive: true });
    el.addEventListener('touchmove', touchMove, { passive: false });
    el.addEventListener('touchend', touchEnd, { passive: true });
    el.addEventListener('touchcancel', touchEnd, { passive: true });
    el.tabIndex = 0;
    el.setAttribute('aria-label', label);
    const resize = new ResizeObserver(update);
    resize.observe(el);
    if (el.firstElementChild) resize.observe(el.firstElementChild);
    update();
    return () => { el.removeEventListener('wheel', wheel); el.removeEventListener('scroll', update); el.removeEventListener('keydown', keyboard); el.removeEventListener('touchstart', touchStart); el.removeEventListener('touchmove', touchMove); el.removeEventListener('touchend', touchEnd); el.removeEventListener('touchcancel', touchEnd); resize.disconnect(); };
  }, [label]);
  function move(direction: number) {
    const el = viewport();
    if (!el) return;
    el.scrollBy({ left: direction * el.clientWidth * .8, behavior: matchMedia('(prefers-reduced-motion: reduce)').matches ? 'instant' : 'smooth' });
  }
  return <div className={`horizontal-rail ${className}`} ref={root}>
    <div className="rail-toolbar"><span className="mono"><MoveHorizontal size={17}/> SWIPE OR SCROLL TO EXPLORE</span><div className="rail-controls"><Button variant="outline" size="icon" onClick={() => move(-1)} disabled={!overflow || progress <= .001} aria-label={`Scroll ${label} left`}><ArrowLeft size={18}/></Button><Button variant="outline" size="icon" onClick={() => move(1)} disabled={!overflow || progress >= .999} aria-label={`Scroll ${label} right`}><ArrowRight size={18}/></Button></div></div>
    <ScrollArea className="rail-area"><div className="rail-track">{children}</div><ScrollBar orientation="horizontal"/></ScrollArea>
    <div className="rail-progress" aria-hidden="true"><span style={{ transform: `translateX(${progress * 300}%)` }}/></div>
  </div>;
}
