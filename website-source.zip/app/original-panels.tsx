'use client';
import { assetPath } from '@/lib/site-path';
import { ArrowUpRight, Trophy } from 'lucide-react';
import { Accordion, AccordionItem, AccordionTrigger, AccordionContent } from '@/components/ui/accordion';
import HorizontalRail from './horizontal-rail';
import content from './original-content.json';

const SPONSOR = 'https://airtable.com/shrbuvuATbemzr71W';
const CONTACT = 'https://airtable.com/appCcGCEUPL3bRRXQ/pagqONOtKNykqYZR8/form';

export function PressLine() {
  return <div className="press-line"><span className="mono">AS SEEN IN</span><div>{content.press.map(press => <img key={press.name} src={assetPath(press.logo)} alt={press.name} loading="lazy"/>)}</div></div>;
}

export function PrizeRails() {
  return <>
    <p className="prize-coming-soon mono">MORE PRIZE INFORMATION COMING SOON</p>
    <HorizontalRail label="platform challenges" className="challenge-rail">
      {content.challenges.map((challenge, i) => <article className="challenge rail-card" key={challenge.name}>
        <span className="mono challenge-index">0{i + 1} / PLATFORM CHALLENGE</span>
        <div className="challenge-logo"><img src={assetPath(challenge.logo)} alt={challenge.name.replace(' Challenge', '')} loading="lazy"/></div>
        <h3>{challenge.name}</h3>
        {challenge.cash ? <strong className="challenge-amount">${challenge.cash.toLocaleString('en-US')}<span className="mono">CASH PRIZE</span></strong> : <strong className="challenge-pending">Challenge details<br/>on the way.</strong>}
        <p>More details coming soon.</p>
      </article>)}
    </HorizontalRail>
    <div className="corporate-heading"><div><span className="mono">CORPORATE CHALLENGE</span><h3>Bring your company.<br/>Take home the glory.</h3></div><Trophy size={38}/></div>
    <p className="corporate-intro">Enter an official company team—or bring multiple teams—to compete against top companies and earn community recognition. Culture Champs celebrates the companies bringing the most teams.</p>
    <HorizontalRail label="corporate awards" className="award-rail">
      {content.awards.map((award, i) => <article className="award-card rail-card" key={award.name}>
        <div className="award-top"><span className="mono">0{i + 1} / CORPORATE AWARD</span><span className="award-places">{award.places} place</span></div>
        <div className="trophy-image"><img src={assetPath(award.image)} alt={`${award.name} trophy`} loading="lazy"/></div>
        <h3>{award.name}</h3><p>{award.facts.join(' ')}</p>
      </article>)}
    </HorizontalRail>
  </>;
}

export function SponsorLineup() {
  return <section id="sponsors" className="sponsors-section"><div className="section wrap">
    <div className="section-kicker mono"><span>06 / THE PEOPLE BEHIND IT</span><span>LOCAL ENERGY. BIG SUPPORT.</span></div>
    <div className="sponsor-heading"><h2>They believe in<br/><span className="serif-word">what you’ll build.</span></h2><div><p className="muted-copy">Their support makes Hack Midwest possible—and helps make Kansas City a better place to live and work in tech.</p><a className="text-link" href={SPONSOR} target="_blank" rel="noreferrer">Become a sponsor <ArrowUpRight size={17}/></a></div></div>
    <div className="sponsor-wall">
        {content.sponsors.map(sponsor => <article key={sponsor.name} className={`sponsor-profile ${sponsor.bio ? 'has-bio' : ''}`}>
          <a className="original-logo-panel" href={sponsor.outbound_url} target="_blank" rel="noreferrer" aria-label={`Visit ${sponsor.name}`}><img src={assetPath(sponsor.logo)} alt={sponsor.name} loading="lazy"/><ArrowUpRight size={16}/></a>
          {sponsor.bio && <Accordion className="sponsor-bio"><AccordionItem value="about"><AccordionTrigger>About {sponsor.name}</AccordionTrigger><AccordionContent><p>{sponsor.bio}</p><a href={sponsor.outbound_url} target="_blank" rel="noreferrer">Visit {sponsor.name} <ArrowUpRight size={14}/></a></AccordionContent></AccordionItem></Accordion>}
        </article>)}
    </div>
    <div className="hosted-by original-host"><span className="mono dim">HOSTED BY</span><a href={content.host.url} target="_blank" rel="noreferrer"><img src={assetPath(content.host.logo)} alt={content.host.name} loading="lazy"/><ArrowUpRight size={15}/></a></div>
  </div></section>;
}

type Entry = { heading: string; facts: string[]; links: { label: string; url: string }[] };
function QuestionList({ entries, prefix, firstOpen = false }: { entries: Entry[]; prefix: string; firstOpen?: boolean }) {
  return <Accordion defaultValue={firstOpen ? [`${prefix}-0`] : []} className="faq-list">{entries.map((entry, i) => <AccordionItem key={entry.heading} value={`${prefix}-${i}`}><AccordionTrigger><span className="faq-number mono">{String(i + 1).padStart(2, '0')}</span>{entry.heading}</AccordionTrigger><AccordionContent>
    {prefix === 'rules' && entry.facts.length > 1 ? <ul className="rule-points">{entry.facts.map(fact => <li key={fact}>{fact}</li>)}</ul> : <p>{entry.facts.join(' ')}</p>}
    {entry.links.map(link => <a className="source-detail-link" key={link.url} href={link.url === 'https://hackmidwest.com/#prizes' ? '#prizes' : link.url} target={link.url.includes('#prizes') ? undefined : '_blank'} rel="noreferrer">{link.label} <ArrowUpRight size={15}/></a>)}
  </AccordionContent></AccordionItem>)}</Accordion>;
}

export function FullQuestions() {
  return <>
    <section id="faq" className="section wrap faq-section"><div className="section-kicker mono"><span>04 / GOOD QUESTIONS</span><span>COME CURIOUS. LEAVE READY.</span></div><div className="faq-grid"><div><h2>A little clarity.<br/><span className="serif-word">A lot of possibility.</span></h2><p className="muted-copy">Frequently asked questions.<br/>Still have something on your mind?</p><a href={CONTACT} className="text-link" target="_blank" rel="noreferrer">Talk to the team <ArrowUpRight size={17}/></a><a href="#rules" className="text-link rules-jump">Explore the competition rules <ArrowUpRight size={17}/></a></div><QuestionList entries={content.faqs} prefix="faq" firstOpen/></div></section>
    <section id="rules" className="section wrap rules-section"><div className="section-kicker mono"><span>05 / THE RULES</span><span>FAIR PLAY. FRESH CODE.</span></div><div className="faq-grid"><div><h2>Play fair.<br/><span className="serif-word">Build fearlessly.</span></h2><p className="muted-copy">Eight essentials for every team.<br/>Know the rules before the clock starts.</p></div><QuestionList entries={content.rules} prefix="rules"/></div></section>
  </>;
}
