export function railMotion(left: number, maximum: number, delta: number) {
  const limit = Math.max(0, maximum);
  const current = Math.min(limit, Math.max(0, left));
  const next = Math.max(0, Math.min(limit, current + delta));
  return { next, consumed: next - current, remainder: delta - (next - current) };
}
