import { assetPath } from '@/lib/site-path';
import type { Metadata } from 'next';
import { Space_Grotesk, Geist, Geist_Mono } from 'next/font/google';
import './globals.css';
const display = Space_Grotesk({ variable: '--font-display', subsets: ['latin'] });
const sans = Geist({ variable: '--font-geist-sans', subsets: ['latin'] });
const mono = Geist_Mono({ variable: '--font-geist-mono', subsets: ['latin'] });
export const metadata: Metadata = {
  title: 'Hack Midwest | Big ideas. Bold builds. | October 10–11',
  description: '350+ builders. 24 hours. $10,000 in cash prizes. Join Kansas City’s largest hackathon, October 10–11. What will you build?',
  icons: { icon: assetPath('/favicon.svg') },
};
export default function RootLayout({ children }: Readonly<{ children: React.ReactNode }>) {
  return <html lang="en"><body className={`${sans.variable} ${mono.variable} ${display.variable}`}>{children}</body></html>;
}
