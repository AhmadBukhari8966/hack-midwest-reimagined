import { access, cp, mkdir, rm, writeFile } from 'node:fs/promises';
import path from 'node:path';
import { startProdServer } from 'vinext/server/prod-server';

const output = path.resolve('dist/client');
const basePath = process.env.NEXT_PUBLIC_BASE_PATH ?? '';
if (basePath && !/^\/[a-zA-Z0-9._-]+(?:\/[a-zA-Z0-9._-]+)*$/.test(basePath)) {
  throw new Error('Expected NEXT_PUBLIC_BASE_PATH to be a URL path such as /hack-midwest-reimagined');
}
// Export the single page through its actual prefixed URL. Vinext beta.5's
// automatic exporter requests '/' even when basePath is configured.
const { server, port } = await startProdServer({
  outDir: path.resolve('dist'), host: '127.0.0.1', port: 0,
  noCompression: true, purpose: 'prerender',
});
try {
  const url = `http://127.0.0.1:${port}${basePath}/`;
  const htmlResponse = await fetch(url);
  const html = await htmlResponse.text();
  if (!htmlResponse.ok || !htmlResponse.headers.get('content-type')?.includes('text/html') || !html.includes('BIG IDEAS.')) {
    throw new Error(`Homepage export failed (${htmlResponse.status})`);
  }
  await writeFile(path.join(output, 'index.html'), html);
  const rscResponse = await fetch(url, { headers: { RSC: '1', Accept: 'text/x-component' } });
  if (!rscResponse.ok || !rscResponse.headers.get('content-type')?.includes('text/x-component')) {
    throw new Error(`Page data export failed (${rscResponse.status})`);
  }
  await writeFile(path.join(output, 'index.rsc'), await rscResponse.text());
  const missing = await fetch(`${url}page-not-found/`);
  if (missing.status !== 404) throw new Error('Expected a 404 for an unknown page');
  await writeFile(path.join(output, '404.html'), await missing.text());
} finally {
  server.closeAllConnections();
  await new Promise((resolve, reject) => server.close(error => error ? reject(error) : resolve()));
}
// Vinext beta.5 stores bundles inside its URL prefix. Pages supplies that prefix.
if (basePath) {
  const nested = path.join(output, basePath.slice(1), '_next');
  await access(nested);
  await mkdir(path.join(output, '_next'), { recursive: true });
  await cp(nested, path.join(output, '_next'), { recursive: true });
  await rm(path.join(output, basePath.slice(1)), { recursive: true });
}
await writeFile(path.join(output, '.nojekyll'), '');
console.log(`GitHub Pages files ready in dist/client for ${basePath || '/'}`);
