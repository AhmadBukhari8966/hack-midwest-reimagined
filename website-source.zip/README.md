# Hack Midwest — Reimagined

A responsive Hack Midwest event website with a blue visual theme, horizontal challenge and award cards, the event schedule, FAQ and rules, and the original sponsor logos.

## Publish on GitHub Pages

1. Upload this project to a public GitHub repository using the `main` branch.
2. Open **Settings → Pages → Build and deployment** and choose **GitHub Actions** as the source.
3. Open **Actions → Publish website → Run workflow**.
4. Open the website address shown by the completed deployment.

The workflow automatically uses the repository's Pages path. Later pushes to `main` publish updates automatically. Only `dist/client` is published as the website.

## Develop locally

Requires Node.js 22.13 or newer and pnpm 11.19.0.

```sh
pnpm install --frozen-lockfile
pnpm dev
```

## Build

```sh
NEXT_PUBLIC_BASE_PATH=/hack-midwest-reimagined pnpm build
```

Use your repository name for the path, or an empty value when publishing at a domain root. The static website is generated in `dist/client`. The preparation script adjusts Vinext beta.5's bundle directory for GitHub Pages.

## Content and assets

- Page layout: `app/page.tsx` and `app/experience.tsx`
- Event information: `app/original-content.json`
- Challenge, award, sponsor and FAQ sections: `app/original-panels.tsx`
- Styling: `app/globals.css`
- Images and original company logos: `public/`

Event information and company logos originate from [Hack Midwest](https://hackmidwest.com/). Company names and logos remain the property of their respective owners.
