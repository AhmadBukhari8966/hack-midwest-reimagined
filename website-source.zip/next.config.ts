import type { NextConfig } from 'next';

const basePath = process.env.NEXT_PUBLIC_BASE_PATH ?? '';
export default {
  trailingSlash: true,
  basePath,
  assetPrefix: basePath,
  images: { unoptimized: true },
} satisfies NextConfig;
